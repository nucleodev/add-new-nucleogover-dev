<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Page Title</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
</head>
<body>
    <footer>
        <p>Copyright Hora News Notícias</p>
    </footer>

    <style>
        footer{
            display: flex;
            align-items: center;
            justify-content: center;
            margin-top: 36.3rem;
            color: white;
            background-color: #1016A4;
        }
    </style>
</body>
</html>