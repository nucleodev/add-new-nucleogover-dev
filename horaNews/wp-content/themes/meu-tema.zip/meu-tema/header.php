<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Hora News</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>

    <link rel="stylesheet" type="text/css" href="style.css">

</head>

<body>

    <header class="header">
        <h1>HORA NEWS</h1>
        <p class="paragrafo-1">NOTÍCIAS</p>
    </header>

    <div class="container">
        
    </div>

    <style>
        .header {
            background-color: #1016A4;
            display: flex;
            align-items: baseline;
            justify-content: center;
            flex-wrap: wrap;
            text-align: center;
            color: white;
            font-family: sans-serif;

        }

        .paragrafo-1 {
            width: 1000rem;
            margin-top: -1rem;
        }

    </style>


</body>

</html>